import os
import json
import pickle
import numpy as np

class MockIrisClassifier:
    """Mock classifier that returns iris predictions based on petal length heuristics"""

    def predict(self, X):
        X = np.array(X)
        predictions = []
        for sample in X:
            petal_length = sample[2] if len(sample) > 2 else 2.5
            if petal_length < 2.5:
                predictions.append(0)
            elif petal_length < 4.9:
                predictions.append(1)
            else:
                predictions.append(2)
        return np.array(predictions)

    def predict_proba(self, X):
        X = np.array(X)
        probas = []
        for sample in X:
            petal_length = sample[2] if len(sample) > 2 else 2.5
            if petal_length < 2.5:
                probas.append([0.95, 0.04, 0.01])
            elif petal_length < 4.9:
                probas.append([0.02, 0.93, 0.05])
            else:
                probas.append([0.01, 0.06, 0.93])
        return np.array(probas)

def model_fn(model_dir):
    # Create model instance directly instead of loading from pickle
    return MockIrisClassifier()

def input_fn(request_body, request_content_type):
    if request_content_type == "application/json":
        data = json.loads(request_body)
        return np.array(data["instances"])
    raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model):
    predictions = model.predict(input_data)
    probabilities = model.predict_proba(input_data)
    return {"predictions": predictions.tolist(), "probabilities": probabilities.tolist()}

def output_fn(prediction, accept):
    if accept == "application/json":
        return json.dumps(prediction), accept
    raise ValueError(f"Unsupported accept type: {accept}")
